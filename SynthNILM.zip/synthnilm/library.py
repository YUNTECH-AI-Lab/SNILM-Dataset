import json, numpy as np

class DeviceLibrary:
    def __init__(self, path):
        with open(path) as f: self._lib=json.load(f)
    def appliances(self): return sorted(self._lib.keys())
    def get_library(self): return self._lib
    def __repr__(self): return f"DeviceLibrary({len(self._lib)} appliances)"
