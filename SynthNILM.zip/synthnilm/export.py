import numpy as np
import pandas as pd
import json
import os

class SynthDataset:
    def __init__(self,houses,n_houses,n_days,seed):
        self.houses=houses; self.n_houses=n_houses; self.n_days=n_days; self.seed=seed
    def __len__(self): return len(self.houses)
    def __getitem__(self,i): return self.houses[i]
    def summary(self):
        means=[h["aggregate"].mean() for h in self.houses]
        print(f"SynthDataset: {self.n_houses} houses x {self.n_days} days")
        print(f"  Mean: {np.mean(means):.1f}W  Min: {np.min(means):.1f}W  Max: {np.max(means):.1f}W")
    def export_csv(self,output_dir):
        os.makedirs(output_dir,exist_ok=True)
        for house in self.houses:
            hid=house["house_id"]; path=os.path.join(output_dir,f"house_{hid:03d}")
            os.makedirs(path,exist_ok=True)
            pd.DataFrame({"timestamp":house["time_index"],"power_W":house["aggregate"]})\
              .to_csv(os.path.join(path,"aggregate.csv"),index=False)
            for app,data in house["channels"].items():
                pd.DataFrame({"timestamp":house["time_index"],"power_W":data})\
                  .to_csv(os.path.join(path,f"{app}.csv"),index=False)
        with open(os.path.join(output_dir,"dataset_metadata.json"),"w") as f:
            json.dump({"n_houses":self.n_houses,"n_days":self.n_days,"seed":self.seed,
                       "sample_rate":"1min","houses":[{"house_id":h["house_id"],
                       "profile":h["profile"],"appliances":h["appliances"]} for h in self.houses]},f,indent=2)
        print(f"CSV export complete: {output_dir}")
    def export_hdf5(self,output_path):
        with pd.HDFStore(output_path,"w",complevel=5,complib="zlib") as store:
            for house in self.houses:
                hid=house["house_id"]; b=f"building{hid}"
                agg=pd.DataFrame(house["aggregate"],index=house["time_index"],
                    columns=pd.MultiIndex.from_tuples([("power","active")],names=["physical_quantity","type"]))
                store.put(f"/{b}/elec/meter1",agg,format="table")
                for k,app in enumerate(sorted(house["channels"].keys()),2):
                    df=pd.DataFrame(house["channels"][app],index=house["time_index"],
                        columns=pd.MultiIndex.from_tuples([("power","active")],names=["physical_quantity","type"]))
                    store.put(f"/{b}/elec/meter{k}",df,format="table")
        print(f"HDF5 export: {output_path} ({os.path.getsize(output_path)/1e6:.1f} MB)")
