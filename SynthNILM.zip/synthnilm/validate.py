import numpy as np

def validate_dataset(dataset, real_stats=None):
    means=[h["aggregate"].mean() for h in dataset.houses]
    report={"n_houses":dataset.n_houses,"mean_power":float(np.mean(means))}
    if real_stats:
        for key in ["mean_power"]:
            if key in real_stats:
                gap=abs(report[key]-real_stats[key])/real_stats[key]
                report[f"{key}_similarity_pct"]=round((1-gap)*100,1)
    return report
