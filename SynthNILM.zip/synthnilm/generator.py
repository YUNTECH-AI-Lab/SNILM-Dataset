import numpy as np
import pandas as pd
import json
import os
from datetime import datetime, timedelta
from .profiles import BEHAVIOR_PROFILES

def sample_power(appliance_name, lib, jitter=0.04):
    if appliance_name not in lib: return 100.0
    instances = lib[appliance_name]
    instance  = instances[np.random.randint(len(instances))]
    samples   = instance.get("on_samples", [])
    power = (float(np.random.choice(samples)) if samples
             else np.random.normal(instance["stats"]["mean_on"],
                                   instance["stats"]["std_on"]*0.3))
    return max(0.0, power + np.random.normal(0, power*jitter))

def generate_day_schedule(appliance, profile_cfg, lib, is_weekend=False, seed=None):
    if seed is not None: np.random.seed(seed)
    timeline = np.zeros(1440, dtype=np.float32)
    cfg = profile_cfg.get(appliance)
    if cfg is None: return timeline
    eff_prob = min(1.0, cfg["prob"]*(cfg["weekend"] if is_weekend else 1.0))
    if np.random.random() > eff_prob: return timeline
    mode=cfg.get("mode","event"); dur_mean=cfg["dur"]; cycles=cfg["cycles"]; hours=cfg["hours"]
    if mode=="continuous":
        cycle_on=dur_mean; cycle_off=max(1,int(1440/cycles)-cycle_on); t=0
        while t<1440:
            on_len=max(1,int(np.random.normal(cycle_on,cycle_on*0.1)))
            power=sample_power(appliance,lib)
            for m in range(t,min(t+on_len,1440)): timeline[m]=max(0,power+np.random.normal(0,power*0.01))
            t+=on_len+max(1,int(np.random.normal(cycle_off,cycle_off*0.1)))
        return timeline
    if mode=="block":
        for _ in range(cycles):
            start=max(0,min(1439,np.random.choice(hours)*60+np.random.randint(-20,20)))
            duration=max(1,int(dur_mean*np.random.uniform(0.85,1.15)))
            end=min(start+duration,1440); power=sample_power(appliance,lib)
            for m in range(start,end): timeline[m]=max(0,power+np.random.normal(0,power*0.03))
        return timeline
    for _ in range(cycles):
        start=max(0,min(1439,np.random.choice(hours)*60+np.random.randint(-25,25)))
        duration=max(1,int(dur_mean*np.random.uniform(0.75,1.25)))
        end=min(start+duration,1440); power=sample_power(appliance,lib)
        for m in range(start,end): timeline[m]+=max(0,power+np.random.normal(0,power*0.02))
    return timeline

def generate_house(house_id, n_days, profile_name, appliances, lib, seed=42):
    np.random.seed(seed+house_id*1000)
    profile=BEHAVIOR_PROFILES[profile_name]
    total_min=n_days*1440
    app_data={app:np.zeros(total_min,dtype=np.float32) for app in appliances}
    start_date=datetime(2024,1,1)+timedelta(days=(house_id-1)*n_days)
    for day in range(n_days):
        day_seed=seed+house_id*10000+day
        is_weekend=(start_date+timedelta(days=day)).weekday()>=5
        start_m=day*1440
        for app in appliances:
            sched=generate_day_schedule(app,profile,lib,is_weekend=is_weekend,seed=day_seed+hash(app)%9999)
            app_data[app][start_m:start_m+1440]=sched
    aggregate=sum(app_data.values()).astype(np.float32)
    bg_noise=np.abs(np.random.normal(2,1,total_min)).astype(np.float32)
    time_index=pd.date_range(start=start_date,periods=total_min,freq="min")
    return {"house_id":house_id,"profile":profile_name,"n_days":n_days,
            "appliances":appliances,"seed":seed,"time_index":time_index,
            "aggregate":aggregate+bg_noise,"channels":app_data}

class SynthNILM:
    def __init__(self, library_path=None, library_dict=None):
        if library_dict: self.lib=library_dict
        elif library_path:
            with open(library_path) as f: self.lib=json.load(f)
        else: raise ValueError("Provide library_path or library_dict")
    def generate(self, n_houses=10, n_days=30, seed=42, profile_mix=None):
        from .export import SynthDataset
        if profile_mix is None:
            profile_mix={"working_family":0.40,"student":0.20,"retired":0.25,"single_professional":0.15}
        profiles=list(profile_mix.keys()); weights=list(profile_mix.values()); houses=[]
        for hid in range(1,n_houses+1):
            np.random.seed(seed+hid)
            profile=np.random.choice(profiles,p=weights)
            prof_apps=list(BEHAVIOR_PROFILES[profile].keys())
            avail=[a for a in prof_apps if a in self.lib]
            h_apps=[a for a in avail if np.random.random()<BEHAVIOR_PROFILES[profile][a]["prob"]]
            for must in ["fridge","lighting"]:
                if must in avail and must not in h_apps: h_apps.append(must)
            house=generate_house(hid,n_days,profile,h_apps,self.lib,seed)
            houses.append(house)
            print(f"  House {hid:>3} | {profile:<22} | {len(h_apps)} appliances")
        return SynthDataset(houses,n_houses=n_houses,n_days=n_days,seed=seed)
