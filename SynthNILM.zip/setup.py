from setuptools import setup, find_packages
setup(name="synthnilm", version="2.0.0",
      description="Synthetic NILM Dataset Generator",
      author="Mohammadreza Abbaspour",
      author_email="m11263021@yuntech.edu.tw",
      url="https://github.com/Mohammadreza-Abp/SNILM-Dataset",
      packages=find_packages(),
      python_requires=">=3.8",
      install_requires=["numpy>=1.21","pandas>=1.3","tables>=3.7"],
      keywords="NILM energy disaggregation synthetic dataset")
