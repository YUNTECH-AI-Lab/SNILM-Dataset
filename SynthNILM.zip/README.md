# SynthNILM

**A Large-Scale Synthetic Benchmark Dataset for Non-Intrusive Load Monitoring**

## Overview

SynthNILM generates realistic synthetic NILM datasets from real UK-DALE and REDD signatures.

- 33 appliance categories
- 4 profiles: Working Family, Retired, Student, Single Professional
- 91.3% similarity to real UK-DALE (Grade A)
- NILMTK-compatible HDF5 output
- Unlimited scale

## Install

```bash
pip install -r requirements.txt
```

## Quick Start

```python
from synthnilm import SynthNILM
from synthnilm.library import DeviceLibrary

lib = DeviceLibrary('device_signature_library_FIXED.json')
gen = SynthNILM(library_dict=lib.get_library())

dataset = gen.generate(n_houses=100, n_days=30, seed=42)
dataset.export_csv('my_dataset/')
dataset.export_hdf5('my_dataset/synthnilm.h5')
dataset.summary()
```

## Browser Generator

Open `synthnilm_generator.html` in any browser — no installation needed.

## Dataset

Pre-generated dataset on Zenodo: **DOI: [to be added]**

## Citation

```bibtex
@article{abbaspour2025synthnilm,
  title  = {A synthetic benchmark dataset for NILM},
  author = {Abbaspour, Mohammadreza and Khodayar, Mahdi and Mofid, Omid and Mobayen, Saleh},
  year   = {2025},
  url = {https://github.com/Mohammadreza-Abp/SNILM-Dataset}
}
```

## License

MIT — see LICENSE
